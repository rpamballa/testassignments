package com.self.tests.stringutilscounter.model;

public class TextRequest {

    private String paragraph;

    public String getParagraph() {
        return paragraph;
    }

    public void setParagraph(String paragraph) {
        this.paragraph = paragraph;
    }
}
